import React, { useState, useContext } from "react";
import { TextField } from "@material-ui/core";
import Input from "@material-ui/core/Input";
import DateFnsUtils from "@date-io/date-fns";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import InputLabel from "@material-ui/core/InputLabel";
import Typography from "@material-ui/core/Typography";
import Slider from "@material-ui/core/Slider";
// import ArrowDownwardIcon from "@material-ui/icons/ArrowDownward";
// import AddCircleIcon from "@material-ui/icons/AddCircle";
import { v4 as uuidv4 } from "uuid";
import TableCell from "@material-ui/core/TableCell";
import moment from "moment";
import Button from "@material-ui/core/Button";
import styled from "styled-components";
// import ReactDom from "react-dom";
import AlertBox from "./layout/AlertBox";
// import { alertContext } from "./App";

// import { makeStyles } from "@material-ui/core/styles";
// import { TextField } from "@material-ui/core";

import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from "@material-ui/pickers";

// const NewRowInputStyles = styled.input`
//   width: ${props => }
// `;

const AddRowButton = styled(Button)`
  width: 80%;
  background-color: rgba(63, 81, 181, 0.04) !important;

  &:hover {
    background-color: rgba(63, 81, 181, 0.07) !important;
  }
`;

export default function AddNewRow({
  setSelectedId,
  oriData,
  setOriData,
  setDialogOpen,
}) {
  const [openAlert, setOpenAlert] = useState(false);
  const [newRowValues, setNewRowValues] = useState({
    id: uuidv4(),
    firstName: "",
    lastName: "",
    Birthdate: `${moment(new Date())
      .format("MM-DD-YYYY")
      .split("T")[0]
      .replace(/-/gi, "/")}`,
    visits: "",
    progress: 0,
    status: "",
    subRows: undefined,
  });

  // const alertContextValues = useContext(alertContext);

  // const { openAlert, setOpenAlert } = alertContextValues;

  // console.log(openAlert);

  // handle adding new row to table

  function handleAddRow() {
    setNewRowValues({
      id: uuidv4(),
      firstName: "",
      lastName: "",
      Birthdate: `${moment(new Date())
        .format("MM-DD-YYYY")
        .split("T")[0]
        .replace(/-/gi, "/")}`,
      visits: "",
      progress: "",
      status: "",
      subRows: undefined,
    });

    setOriData([...oriData, newRowValues]);

    setOpenAlert(true);
    setTimeout(() => {
      setOpenAlert(false);
    }, 2500);

    // return <Alert severity="success">Added a row !</Alert>;
    // alert("row added");
    // setOriData(oriValuesCopy);
  }

  // console.log(newRowValues);
  //   console.log(i);
  return (
    <>
      <TableCell
        className="global-filter-th hovered-none"
        style={{ padding: "5px 8px" }}
      >
        {" "}
        <Input
          placeholder="First Name"
          value={newRowValues.firstName}
          inputProps={{ "aria-label": "description" }}
          style={{ maxWidth: "150px" }}
          onChange={(e) => {
            setNewRowValues({ ...newRowValues, firstName: e.target.value });
          }}
        />
      </TableCell>
      <TableCell
        className="global-filter-th hovered-none"
        style={{ padding: "5px 8px" }}
      >
        {" "}
        <Input
          placeholder="Last Name"
          value={newRowValues.lastName}
          inputProps={{ "aria-label": "description" }}
          style={{ maxWidth: "150px" }}
          onChange={(e) => {
            setNewRowValues({ ...newRowValues, lastName: e.target.value });
          }}
        />
      </TableCell>
      <TableCell
        className="global-filter-th hovered-none"
        style={{ padding: "5px 8px" }}
      >
        {" "}
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <KeyboardDatePicker
            margin="normal"
            id="date-picker-dialog"
            label="Date picker dialog"
            format="MM/dd/yyyy"
            value={newRowValues.Birthdate}
            // defaultValue={newRowValues.Birthdate}
            style={{ maxWidth: "200px" }}
            KeyboardButtonProps={{
              "aria-label": "change date",
            }}
            onChange={(e) => {
              // console.log(e);
              setNewRowValues({
                ...newRowValues,
                Birthdate: moment(e)
                  .format("MM-DD-YYYY")
                  .split("T")[0]
                  .replace(/-/gi, "/"),
              });
            }}
          />
        </MuiPickersUtilsProvider>
      </TableCell>
      <TableCell
        className="global-filter-th hovered-none"
        style={{ padding: "5px 8px" }}
      >
        {" "}
        <Input
          id="standard-number"
          label="Number"
          type="number"
          inputProps={{ min: "0", max: "50" }}
          style={{ minWidth: "100px" }}
          value={newRowValues.visits}
          placeholder="visits"
          inputlabelprops={{
            shrink: true,
          }}
          onChange={(e) =>
            setNewRowValues({ ...newRowValues, visits: e.target.value })
          }
        />
      </TableCell>
      <TableCell
        className="global-filter-th hovered-none"
        style={{ padding: "5px 8px" }}
      >
        {" "}
        <FormControl style={{ width: "100%", marginTop: "-16px" }}>
          <InputLabel id="demo-simple-select-label">Status</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            placeholder="Status"
            id="demo-simple-select"
            style={{ minWidth: "100px" }}
            value={newRowValues.status}
            onChange={(e) =>
              setNewRowValues({ ...newRowValues, status: e.target.value })
            }
          >
            <MenuItem value="single">Single</MenuItem>
            <MenuItem value="married">Married</MenuItem>
          </Select>
        </FormControl>
      </TableCell>
      <TableCell
        className="global-filter-th hovered-none"
        style={{ padding: "5px 8px" }}
      >
        {" "}
        <Typography gutterBottom style={{ marginBottom: "0" }}>
          Progress
        </Typography>
        <Slider
          value={newRowValues.progress}
          valueLabelDisplay="auto"
          style={{ width: "80%" }}
          onChange={(e, newV) => {
            setNewRowValues({
              ...newRowValues,
              progress: newV,
            });
          }}
          aria-labelledby="continuous-slider"
        />
      </TableCell>
      <TableCell
        className="global-filter-th hovered-none"
        style={{ padding: "5px 8px" }}
      >
        <AddRowButton
          // variant="outlined"
          // style={AddRowButton}
          color="primary"
          // style={{ width: "80%", backgroundColor: "rgba(63, 81, 181, 0.04)" }}
          onClick={handleAddRow}
        >
          Add
        </AddRowButton>
      </TableCell>
      {openAlert && (
        <AlertBox
          setOpenAlert={setOpenAlert}
          content="Added new row."
          refer="add"
        ></AlertBox>
      )}
      {/* {openAlert && (
       
      )} */}
    </>
  );
}
