import React, { useState, useEffect } from "react";
import ReactDom from "react-dom";
import styled from "styled-components";
import Alert from "@material-ui/lab/Alert";

const AlertBoxStyles = styled(Alert)`
  position: fixed;
  bottom: 0;
  transition: all 400ms;
  left: 5%;
  opacity: 1;
  transform: translate(-5%, -30px);
  z-index: 999;
`;

export default function AlertBox({ setOpenAlert, className, content, refer }) {
  // const [numberOfAlertBoxes,setNumberOfAlertBoxes ] = useState([]);

  // useEffect(() => {
  //     if (openAlert)
  // }, [openAlert])

  return ReactDom.createPortal(
    <AlertBoxStyles
      className={className}
      variant="filled"
      severity={`${refer === "add" ? "success" : "error"}`}
      onClose={() => setOpenAlert(false)}
    >
      {content}
    </AlertBoxStyles>,
    document.getElementById("layout-portal")
  );
}
