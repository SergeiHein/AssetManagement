import React, { useState } from "react";
import DialogTitle from "@material-ui/core/DialogTitle";
import Dialog from "@material-ui/core/Dialog";
// import PropTypes from "prop-types";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import { DialogContent } from "@material-ui/core";
import Slider from "@material-ui/core/Slider";
import Button from "@material-ui/core/Button";
import DateFnsUtils from "@date-io/date-fns";
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import moment from "moment";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import styled from "styled-components";
import Typography from "@material-ui/core/Typography";
// import Slider from "@material-ui/core/Slider";

const EditableInputStyles = styled(TextField)`
  width: 100%;
`;

export default function EditTableData({
  selectedRow,
  dialogOpen,
  handleEditChange,
  setDialogOpen,
}) {
  const [newValues, setNewValues] = useState({
    ...selectedRow,
  });

  function handleChange(changes) {
    handleEditChange(selectedRow.id, { ...newValues, ...changes });
  }

  return (
    <Dialog
      aria-labelledby="simple-dialog-title"
      open={dialogOpen}
      onClose={() => setDialogOpen(false)}
    >
      <DialogTitle>Hi</DialogTitle>
      <DialogContent>
        <Grid container spacing={3} style={{ margin: "0", width: "100%" }}>
          <Grid item xs={6}>
            <EditableInputStyles
              required
              id="standard-required"
              label="Enter your name"
              onChange={(e) =>
                setNewValues({ ...newValues, firstName: e.target.value })
              }
              value={newValues.firstName}
            />
          </Grid>
          <Grid item xs={6}>
            <EditableInputStyles
              required
              // id="standard-required"
              label="Enter your name"
              onChange={(e) =>
                setNewValues({ ...newValues, lastName: e.target.value })
              }
              value={newValues.lastName}
            />
          </Grid>
          <Grid item xs={6}>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
              <KeyboardDatePicker
                margin="normal"
                id="date-picker-dialog"
                label="Date picker dialog"
                format="MM/dd/yyyy"
                maxDate={new Date()}
                value={newValues.Birthdate}
                onChange={(e) => {
                  setNewValues({
                    ...newValues,
                    Birthdate: moment(e)
                      .format()
                      .split("T")[0]
                      .replace(/-/gi, "/"),
                  });
                }}
                KeyboardButtonProps={{
                  "aria-label": "change date",
                }}
              />
            </MuiPickersUtilsProvider>
          </Grid>
          <Grid item xs={6}>
            <EditableInputStyles
              style={{ width: "100%" }}
              required
              id="standard-number"
              //   label="Number"
              type="number"
              inputProps={{ min: "0", max: "50" }}
              // id="standard-required"
              label="Enter your visits"
              onChange={(e) =>
                setNewValues({ ...newValues, visits: e.target.value })
              }
              value={newValues.visits}
            />
          </Grid>
          <Grid item xs={6}>
            <FormControl style={{ width: "100%" }}>
              <InputLabel id="demo-simple-select-label">Status</InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={newValues.status}
                onChange={(e) =>
                  setNewValues({ ...newValues, status: e.target.value })
                }
              >
                <MenuItem value="single">Single</MenuItem>
                <MenuItem value="married">Married</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            {/* <Typography id="discrete-slider" gutterBottom>
              Progress
            </Typography>
            <EditableInputStyles
              style={{ width: "100%" }}
              required
              type="number"
              inputProps={{ min: "0", max: "100" }}
              // id="standard-required"
              label="Enter your visits"
              onChange={(e) =>
                setNewValues({ ...newValues, progress: e.target.value })
              }
              value={newValues.progress}
            /> */}
            <Typography gutterBottom>Progress</Typography>
            <Slider
              value={newValues.progress}
              valueLabelDisplay="auto"
              onChange={(e, newV) => {
                setNewValues({
                  ...newValues,
                  progress: newV,
                });
              }}
              // min={0}
              // max={100}
              // step={10}
              // marks
              aria-labelledby="continuous-slider"
            />
          </Grid>
        </Grid>
        <Button
          variant="contained"
          color="primary"
          // type="submit"
          onClick={() => {
            // departments.push(newValue);
            handleChange(newValues);
            setDialogOpen(false);
            // setOpen(false);
          }}
          style={{ minWidth: "80px", margin: "0 auto" }}
        >
          Update
        </Button>
      </DialogContent>

      {/* <DialogTitle id="simple-dialog-title">Set backup account</DialogTitle> */}
    </Dialog>
  );
}
