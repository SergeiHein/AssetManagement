import React, { useState, useEffect } from "react";
import ListFormTableIndex from "./listFormTable/ListFormTableIndex";
import styled from "styled-components";
import IconButton from "@material-ui/core/IconButton";
import TextField from "@material-ui/core/TextField";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import PhotoCamera from "@material-ui/icons/PhotoCamera";
import { useSubheader } from "../../../layout";
import Autocomplete from "@material-ui/lab/Autocomplete";
import Fab from "@material-ui/core/Fab";
import AddBoxIcon from "@material-ui/icons/AddBox";
// import AddBoxIcon from "@material-ui/icons/Add";
import InputDialog from "./listFormTable/CategoryInputDialog";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { appsetting } from "../../../../envirment/appsetting";
// import FormControl from "@material-ui/core/FormControl";

import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import moment from "moment";
import CloudUploadIcon from "@material-ui/icons/CloudUpload";
// import { parse } from "date-fns";

const ListFormWrapper = styled.div`
  width: 100%;
  margin-bottom: 50px;
  box-shadow: 0 0 50px 0 rgba(82, 63, 105, 0.15) !important;
  background: #fff;
`;

const SelectStyles = styled(Select)`
  width: 100% !important;
`;

const ListForm = styled.form`
  width: 75%;
  padding: 25px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  min-height: 500px;
  justify-content: space-around;

  .MuiGrid-spacing-xs-3 > .MuiGrid-item {
    display: flex;
    /* justify-content: flex-end; */
    align-items: center;
  }

  .MuiGrid-spacing-xs-3 > .MuiGrid-item:nth-child(even) {
    justify-content: flex-end;
  }

  .MuiFormControl-root {
    width: 50% !important;
  }

  .description-grid .MuiFormControl-root {
    /* display: none; */
    width: 70% !important;

    textarea {
      min-height: 75px;
    }
  }
`;

export const categories = ["reusable", "permanent", "fixed", "technologies"];
export const assetNames = ["chair", "table", "laptop", "cup"];

export default function ListFormIndex() {
  const { server_path } = appsetting;

  // console.log(server_path);
  const suhbeader = useSubheader();
  suhbeader.setTitle("List Form");
  const [formData, setFormData] = useState({
    type: "",
    category: "",
    date: `${moment(new Date())
      .format("MM-DD-YYYY")
      .split("T")[0]
      .replace(/-/gi, "/")}`,
    assetName: "",
    purchaseQuantity: undefined,
    remainingQuantity: 0,
    totalQuantity: 0,
    isRequestable: true,
    location: "",
    photoPath: "",
    description: "",
  });
  const [showListFormTable, setShowListFormTable] = useState(false);
  const [hideLicenseColumns, setHideLicenseColumns] = useState(null);
  const [assetNameOptionLabels, setAssetNameOptionLabels] = useState({
    options: assetNames,
  });
  const [categoryOptionLabels, setCategoryOptionLabels] = useState({
    options: categories,
  });
  const [open, setOpen] = useState(false);
  const [selectedValue, setSelectedValue] = useState("");
  const [title, setTitle] = useState("");
  const [assetTypeId, setAssetTypeId] = useState("");

  // const [c]

  // const filteredValuesByType = formData.find(one => one.asset_id === id);

  const handleClickOpen = (value) => {
    setOpen(true);
    if (value.toLowerCase() === "asset") {
      setTitle("asset");
    } else {
      setTitle("category");
    }
    // setTitle('')
  };

  const handleClose = (value) => {
    setOpen(false);
    // setSelectedValue(value);
  };

  function handleListFormSubmit(e) {
    // console.log(formData.type);
    // setShowListFormTable(!showListFormTable);
    // setLsFlag(!lsFlag);
    setHideLicenseColumns(
      formData.type.toLocaleLowerCase() === "license" ? true : false
    );
    setShowListFormTable(false);
    setTimeout(() => {
      setShowListFormTable(true);
    }, 100);
    e.preventDefault();
  }

  // console.log(formData.photoPath)
  return (
    <>
      <ListFormWrapper>
        <ListForm autoComplete="off" onSubmit={handleListFormSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={6}>
              <FormControl>
                <InputLabel id="demo-simple-select-label" required>
                  Type
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  required
                  value={formData.type}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      type: e.target.value,
                    })
                  }
                >
                  <MenuItem value="Asset">Asset</MenuItem>
                  <MenuItem value="Components">Components</MenuItem>
                  <MenuItem value="License">License</MenuItem>
                  <MenuItem value="consumable">consumable</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <TextField
                disabled
                id="filled-disabled"
                label="Total quantity"
                // defaultValue="Hello World"
                value={formData.totalQuantity}
                variant="filled"
                tabIndex="-1"
              />
            </Grid>

            <Grid item xs={6} style={{ position: "relative" }}>
              <Autocomplete
                {...categoryOptionLabels}
                id="auto-select"
                autoSelect
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Category"
                    margin="normal"
                    onSelect={(e) => {
                      setFormData({
                        ...formData,
                        category: e.target.value,
                      });
                    }}
                  />
                )}
                style={{ flex: "1" }}
              />
              {/* <Fab
                color="primary"
                aria-label="add"
                size="small"
                onClick={() => handleClickOpen("category")}
                style={{
                  position: "absolute",
                  top: "50%",
                  left: "60%",
                  transform: "translate(-60%, -50%)",
                  minHeight: "30px",
                  width: "30px",
                  height: "30px",
                }}
              > */}
              <AddBoxIcon
                // style={{ color: "#fff" }}
                onClick={() => handleClickOpen("category")}
                style={{
                  position: "absolute",
                  top: "63%",
                  left: "60%",
                  transform: "translate(-60%, -63%)",
                  minHeight: "20px",
                  width: "20px",
                  height: "20px",
                  cursor: "pointer",
                  color: "#3783e7",
                }}
              />
              {/* </Fab> */}
              <InputDialog
                selectedValue={selectedValue}
                open={open}
                onClose={handleClose}
                // setCategoryLabels={setCategoryLabels}
                setAssetNameOptionLabels={setAssetNameOptionLabels}
                setCategoryOptionLabels={setCategoryOptionLabels}
                setOpen={setOpen}
                title={title}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                id="standard-number"
                label="Purchase Quantity"
                type="number"
                // min={0}
                // max={100}
                required
                value={formData.purchaseQuantity}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    purchaseQuantity: parseFloat(e.target.value),
                  })
                }
                inputProps={{ min: "0", max: "100" }}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>

            <Grid item xs={6} style={{ position: "relative" }}>
              {" "}
              <Autocomplete
                {...assetNameOptionLabels}
                id="auto-select"
                autoSelect
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Asset Name"
                    margin="normal"
                    // value={formData.assetName}
                    onSelect={(e) => {
                      setFormData({
                        ...formData,
                        assetName: e.target.value,
                      });
                    }}
                  />
                )}
                style={{ flex: "1" }}
              />
              <AddBoxIcon
                // style={{ color: "#fff" }}
                onClick={() => handleClickOpen("asset")}
                style={{
                  position: "absolute",
                  top: "63%",
                  left: "60%",
                  transform: "translate(-60%, -63%)",
                  minHeight: "20px",
                  width: "20px",
                  height: "20px",
                  cursor: "pointer",
                  color: "#3783e7",
                }}
              />
              {/* </Fab> */}
              <InputDialog
                selectedValue={selectedValue}
                open={open}
                onClose={handleClose}
                setAssetNameOptionLabels={setAssetNameOptionLabels}
                setCategoryOptionLabels={setCategoryOptionLabels}
                setOpen={setOpen}
                title={title}
              />
            </Grid>
            <Grid item xs={6}>
              <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <KeyboardDatePicker
                  margin="normal"
                  id="date-picker-dialog"
                  label="Purchase Date"
                  format="MM/dd/yyyy"
                  maxDate={new Date()}
                  value={formData.date}
                  onChange={(e) => {
                    setFormData({
                      ...formData,
                      date: moment(e)
                        .format()
                        .split("T")[0]
                        .replace(/-/gi, "/"),
                    });
                  }}
                  KeyboardButtonProps={{
                    "aria-label": "change date",
                  }}
                />
              </MuiPickersUtilsProvider>
            </Grid>
            <Grid item xs={6}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formData.isRequestable}
                    // defaultChecked={false}
                    onChange={(e) => {
                      setFormData({
                        ...formData,
                        isRequestable: e.target.checked,
                      });
                    }}
                    name="checkedA"
                  />
                }
                label="Requestable"
              />
              {/* <Checkbox
                defaultChecked
                
                
                color="primary"
                inputProps={{ "aria-label": "secondary checkbox" }}

              /> */}
            </Grid>

            <Grid item xs={6}>
              <TextField
                // id="standard-number"
                label="Remaining Quantity"
                disabled
                id="filled-disabled"
                variant="filled"
                type="number"
                inputProps={{ min: "0", max: "100" }}
                value={formData.remainingQuantity}
                InputLabelProps={{
                  shrink: true,
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <FormControl>
                <InputLabel id="demo-simple-select-label">Location</InputLabel>
                <SelectStyles
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={formData.supplier}
                  onChange={(e) => {
                    setFormData({ ...formData, location: e.target.value });
                  }}
                >
                  <MenuItem value={10}>Ten</MenuItem>
                  <MenuItem value={20}>Twenty</MenuItem>
                  <MenuItem value={30}>Thirty</MenuItem>
                </SelectStyles>
              </FormControl>
            </Grid>
            <Grid item xs={6}>
              <input
                accept="image/*"
                id="icon-button-file"
                type="file"
                tabIndex="2"
                onChange={(e) => {
                  const url = URL.createObjectURL(e.target.files[0]);
                  setFormData({
                    ...formData,
                    photoPath: url,
                  });
                }}
                style={{ display: "none" }}
              />
              <label htmlFor="icon-button-file">
                <Button
                  variant="contained"
                  color="secondary"
                  component="span"
                  startIcon={<CloudUploadIcon />}
                >
                  Upload
                </Button>
              </label>
            </Grid>
            <Grid item xs={6} className="description-grid">
              <TextField
                id="outlined-multiline-static"
                label="Description"
                value={formData.description}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    description: e.target.value,
                  })
                }
                multiline
                rows={4}
                variant="outlined"
              />
            </Grid>
          </Grid>
          <Button
            variant="contained"
            color="primary"
            type="submit"
            style={{
              color: "#fff",
              width: "60%",
              margin: "30px auto 0 auto",
              height: "35px",
            }}
          >
            Get Asset Tags
          </Button>
        </ListForm>
      </ListFormWrapper>
      {showListFormTable && (
        <ListFormTableIndex
          quantity={formData.purchaseQuantity}
          hideLicenseColumns={hideLicenseColumns}
          formData={formData}
          // lsFlag={lsFlag}
        ></ListFormTableIndex>
      )}
    </>
  );
}
