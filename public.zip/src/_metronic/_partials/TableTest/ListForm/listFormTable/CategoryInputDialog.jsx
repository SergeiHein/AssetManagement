import React, { useState } from "react";
import DialogTitle from "@material-ui/core/DialogTitle";
import Dialog from "@material-ui/core/Dialog";
import PropTypes from "prop-types";
import { categories } from "../ListFormIndex";
import { assetNames } from "../ListFormIndex";
// import { useStyles } from "../App";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import styled from "styled-components";

const DialogStyles = styled(Dialog)`
  .MuiDialog-paper {
    min-width: 300px;
    justify-content: space-evenly;
    align-items: center;
    height: 300px;
  }
`;

export default function InputDialog(props) {
  // const classes = useStyles();
  const { onClose, open, setOpen, title } = props;

  console.log(title);
  const [newValue, setNewValue] = useState();
  //setOpen(false);

  const handleClose = () => {
    setOpen(false);
  };

  //const handleListItemClick = (value) => {
  //    onClose(value);
  //};

  return (
    <DialogStyles
      onClose={handleClose}
      aria-labelledby="simple-dialog-title"
      open={open}
    >
      <DialogTitle id="simple-dialog-title">
        {title === "asset" ? "Add Asset Name" : "Add Category"}
      </DialogTitle>

      {/* <form
        onSubmit={(e) => {
          e.preventDefault();

          departments.push(newValue);
          setOpen(false);
        }}
      > */}
      <TextField
        required
        id="standard-required"
        label={title === "asset" ? "Asset Name" : "Category Name"}
        onChange={(e) => {
          setNewValue(e.target.value);
        }}
        style={{ width: "80%", margin: "0 auto" }}
        //placeholder="Enter your name"
      />

      <Button
        variant="contained"
        color="primary"
        // type="submit"
        onClick={() => {
          if (title === "asset") {
            assetNames.push(newValue);
          } else {
            categories.push(newValue);
          }
          setOpen(false);
        }}
        style={{ minWidth: "80px", margin: "0 auto", color: "#fff" }}
      >
        {title === "asset" ? "Add Asset Name" : "Add Category"}
      </Button>
      {/* </form> */}
    </DialogStyles>
  );
}

InputDialog.propTypes = {
  onClose: PropTypes.func.isRequired,
  open: PropTypes.bool.isRequired,
  selectedValue: PropTypes.string.isRequired,
};
