import React, { useState } from "react";
import DialogTitle from "@material-ui/core/DialogTitle";
import Dialog from "@material-ui/core/Dialog";
// import PropTypes from "prop-types";
import Grid from "@material-ui/core/Grid";
// import { withStyles, makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import { DialogContent } from "@material-ui/core";
import Slider from "@material-ui/core/Slider";
import Button from "@material-ui/core/Button";
import DateFnsUtils from "@date-io/date-fns";
import Typography from "@material-ui/core/Typography";
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker,
} from "@material-ui/pickers";
import moment from "moment";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
// import MenuItem from "@material-ui/core/MenuItem";
import styled from "styled-components";
// import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormHelperText from "@material-ui/core/FormHelperText";
// import FormControl from '@material-ui/core/FormControl';
// import Select from '@material-ui/core/Select';
// import Typography from "@material-ui/core/Typography";

const EditableInputStyles = styled(TextField)`
  width: 100%;
`;

const EditableListFormStyles = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  margin-top: 20px;
`;

const DialogStyles = styled(Dialog)`
  .MuiDialog-paper {
    padding: 15px;
  }
`;

const SelectStyles = styled(Select)`
  width: 100% !important;
`;

export default function EditTableData({
  selectedRow,
  dialogOpen,
  handleEditChange,
  setDialogOpen,
}) {
  const [newValues, setNewValues] = useState({
    ...selectedRow,
  });
  const [LSValues, setLSValues] = useState([]);

  // console.log(newValues);

  function handleChange(changes) {
    handleEditChange(selectedRow.id, { ...newValues, ...changes });
  }
  // console.log(newValues);
  return (
    <DialogStyles
      aria-labelledby="simple-dialog-title"
      open={dialogOpen}
      onClose={() => setDialogOpen(false)}
      // style={{ padding: "15px !important" }}
    >
      <DialogTitle style={{ padding: "0px" }}>
        <Typography variant="h6" gutterBottom align={"center"}>
          Update
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Grid container spacing={3} style={{ margin: "0", width: "100%" }}>
          {(newValues.supplier !== undefined || null) && (
            <Grid item xs={6}>
              <FormControl style={{ width: "100%" }}>
                <InputLabel id="demo-simple-select-label">Supplier</InputLabel>
                <SelectStyles
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={newValues.supplier}
                  onChange={(e) => {
                    setNewValues({ ...newValues, supplier: e.target.value });
                  }}
                >
                  <MenuItem value={10}>Ten</MenuItem>
                  <MenuItem value={20}>Twenty</MenuItem>
                  <MenuItem value={30}>Thirty</MenuItem>
                </SelectStyles>
              </FormControl>
              {/* <EditableInputStyles
                required
                id="standard-required"
                label="Supplier"
                onChange={(e) => {
                  setNewValues({ ...newValues, supplier: e.target.value });
                }}
                value={newValues.supplier}
              /> */}
            </Grid>
          )}

          {(newValues.brand !== undefined || null) && (
            <Grid item xs={6}>
              <EditableInputStyles
                required
                label="Brand"
                onChange={(e) =>
                  setNewValues({ ...newValues, brand: e.target.value })
                }
                value={newValues.brand}
              />
            </Grid>
          )}
          {(newValues.model_no !== undefined || null) && (
            <Grid item xs={6}>
              <EditableInputStyles
                required
                label="Model No."
                onChange={(e) =>
                  setNewValues({ ...newValues, model_no: e.target.value })
                }
                value={newValues.model_no}
              />
            </Grid>
          )}
          {(newValues.status !== undefined || null) && (
            <Grid item xs={6}>
              {/* <EditableInputStyles
                required
                label="Brand"
                onChange={(e) =>
                  setNewValues({ ...newValues, brand: e.target.value })
                }
                value={newValues.brand}
              /> */}
              <FormControl style={{ width: "100%" }}>
                <InputLabel id="demo-simple-select-label">Status</InputLabel>
                <SelectStyles
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={newValues.status}
                  onChange={(e) => {
                    setNewValues({ ...newValues, status: e.target.value });
                  }}
                >
                  <MenuItem value="active">Active</MenuItem>
                  <MenuItem value="not active">Not active</MenuItem>
                </SelectStyles>
              </FormControl>
            </Grid>
          )}

          {(newValues.cost !== undefined || null) && (
            <Grid item xs={6}>
              <EditableInputStyles
                required
                type="number"
                label="Cost (kyat)"
                onChange={(e) =>
                  setNewValues({ ...newValues, cost: e.target.value })
                }
                value={newValues.cost}
              />
            </Grid>
          )}
          {(newValues.warranty !== undefined || null) && (
            <Grid item xs={6}>
              <EditableInputStyles
                required
                type="number"
                label="Warranty (years)"
                onChange={(e) =>
                  setNewValues({ ...newValues, warranty: e.target.value })
                }
                value={newValues.warranty}
              />
            </Grid>
          )}

          {(newValues.exp_date !== undefined || null) && (
            <Grid item xs={6}>
              <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <KeyboardDatePicker
                  margin="normal"
                  id="date-picker-dialog"
                  label="Expiry Date"
                  format="MM/dd/yyyy"
                  maxDate={new Date()}
                  value={newValues.exp_date}
                  onChange={(e) => {
                    console.log(e);
                    setNewValues({
                      ...newValues,
                      exp_date: moment(e)
                        .format()
                        .split("T")[0]
                        .replace(/-/gi, "/"),
                    });
                  }}
                  KeyboardButtonProps={{
                    "aria-label": "change date",
                  }}
                />
              </MuiPickersUtilsProvider>
            </Grid>
          )}

          {(newValues.asset_tag !== undefined || null) && (
            <Grid item xs={6}>
              <EditableInputStyles
                style={{ width: "100%" }}
                type="number"
                disabled
                id="filled-disabled"
                label="Asset Tag"
                defaultValue={newValues.asset_tag}
                variant="filled"
              />
            </Grid>
          )}

          {(newValues.product_key !== undefined || null) && (
            <Grid item xs={6}>
              <EditableInputStyles
                // required
                // disabled
                id="standard-number"
                type="number"
                label="Product Key"
                // variant="filled"
                onChange={(e) =>
                  setNewValues({ ...newValues, product_key: e.target.value })
                }
                value={newValues.product_key}
              />
            </Grid>
          )}
          {(newValues.serial_no !== undefined || null) && (
            <Grid item xs={6}>
              <EditableInputStyles
                // required
                // disabled
                id="standard-number"
                // id="standard-required"
                label="Serial Number"
                // variant="filled"
                onChange={(e) =>
                  setNewValues({ ...newValues, serial_no: e.target.value })
                }
                value={newValues.serial_no}
              />
            </Grid>
          )}

          {/* <Grid item xs={6}></Grid> */}
        </Grid>
        <EditableListFormStyles>
          <Button
            variant="contained"
            color="primary"
            onClick={() => {
              handleChange(newValues);
              setDialogOpen(false);
            }}
            style={{ minWidth: "80px", color: "#fff" }}
          >
            Update
          </Button>
          <Button
            color="secondary"
            onClick={() => {
              setDialogOpen(false);
            }}
            style={{ minWidth: "80px" }}
          >
            Cancel
          </Button>
        </EditableListFormStyles>
      </DialogContent>

      {/* <DialogTitle id="simple-dialog-title">Set backup account</DialogTitle> */}
    </DialogStyles>
  );
}
