import React, { useMemo, useState, useEffect } from "react";
import MakeDataListForm from "./MakeDataListForm";
import MakeTableListForm from "./MakeTableListForm";
import styled from "styled-components";
import CreateIcon from "@material-ui/icons/Create";
import EditTableData from "./EditableListFormTable";
import IconButton from "@material-ui/core/IconButton";
import AlertBox from "../../layout/AlertBox";
import Tooltip from "@material-ui/core/Tooltip";
import Button from "@material-ui/core/Button";

// import Axios from "axios";

const Styles = styled.div`
  width: 100%;
  margin: 0px auto 0 auto;
  /* margin-top: 70px; */
`;

const EditButton = styled(IconButton)`
  padding: 7px !important;
  border-radius: 4px !important;
  background: rgba(54, 153, 255, 0.5) !important;
  transition: all 300ms;

  svg {
    color: #fff;
  }
  &:hover {
    background-color: rgba(54, 153, 255, 0.8) !important;
  }
`;

const FinalSubmitBtn = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  margin-top: 30px;
`;

export default function App({ hideLicenseColumns, quantity, formData }) {
  const [oriData, setOriData] = useState(
    MakeDataListForm(hideLicenseColumns, quantity)
  );

  // console.log(oriData);

  // console.log(formTableLsValues);
  const [selectedId, setSelectedId] = useState();
  const selectedRow = oriData.find((row) => row.id === selectedId);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [openAlert, setOpenAlert] = useState(false);

  // const [lsTableValues, setLsTableValues] = useState();

  function handleEditChange(id, changes) {
    const newValues = [...oriData];

    const index = newValues.findIndex((value) => value.id === id);

    newValues[index] = changes;

    setOriData(newValues);
  }

  function submitFormData(e) {
    console.log([oriData, formData]);
  }

  const columns = React.useMemo(
    () => [
      {
        Header: "Supplier",
        accessor: "supplier",
      },
      {
        Header: "Brand",
        accessor: "brand",
      },
      {
        Header: "Model No.",
        accessor: "mode_no",
      },
      {
        Header: "Status",
        accessor: "status",
      },
      {
        Header: "Cost",
        accessor: "cost",
      },
      {
        Header: "Warranty",
        accessor: "warranty",
        show: hideLicenseColumns,
      },
      {
        Header: "ExpDate",
        accessor: "exp_date",
        show: hideLicenseColumns,
      },
      {
        Header: "Asset Tag",
        accessor: "asset_tag",
      },
      {
        Header: "Product Key",
        accessor: "product_key",
      },
      {
        Header: "Serial No.",
        accessor: "serial_no",
      },

      {
        Header: "Actions",
        id: "delete",

        Cell: (tableProps) => {
          return (
            <>
              <span
                style={{
                  cursor: "pointer",
                  color: "grey",
                  textDecoration: "underline",
                }}
                onClick={(event) => {
                  let id =
                    event.currentTarget.parentElement.parentElement.dataset.id;
                  setDialogOpen(true);
                  // console.log(tableProps.data[id]);
                  setSelectedId(id);

                  // EditTableData(selectedId, );
                }}
              >
                <Tooltip title="Edit Row">
                  <EditButton aria-label="edit">
                    <CreateIcon fontSize="small" />
                  </EditButton>
                </Tooltip>
              </span>
            </>
          );
        },
      },
    ],
    [hideLicenseColumns]
  );

  const data = useMemo(() => oriData, [oriData]);

  // console.log(selectedRow);
  return (
    // <alertContext.Provider value={contextValues}>
    <Styles>
      <MakeTableListForm
        columns={columns}
        data={data}
        hideLicenseColumns={hideLicenseColumns}
      ></MakeTableListForm>
      <FinalSubmitBtn>
        <Button
          variant="contained"
          color="primary"
          type="submit"
          onClick={submitFormData}
          style={{ width: "50%", color: "#fff" }}
        >
          Submit
        </Button>
      </FinalSubmitBtn>
      {openAlert && (
        <AlertBox
          setOpenAlert={setOpenAlert}
          content="deleted row."
          refer="delete"
        ></AlertBox>
      )}
      {dialogOpen && (
        <EditTableData
          selectedRow={selectedRow}
          setDialogOpen={setDialogOpen}
          dialogOpen={dialogOpen}
          handleEditChange={handleEditChange}
        ></EditTableData>
      )}
    </Styles>
  );
}
