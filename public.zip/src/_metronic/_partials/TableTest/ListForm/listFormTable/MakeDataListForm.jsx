import React from "react";
// import React from "react";
import namor from "namor";
import { v4 as uuidv4 } from "uuid";
import momentRandom from "moment-random";
import moment from "moment";

function makeRow(hideLicenseColumns) {
  // const chance = Math.random();

  // console.log(JSON.stringify(moment(new Date()).format().split("+")[0]));

  return {
    id: uuidv4(),
    supplier: "",
    brand: "",
    model_no: "",
    status: "",
    cost: "",
    warranty: hideLicenseColumns ? undefined : "",
    exp_date: hideLicenseColumns
      ? undefined
      : `${moment(new Date())
          .format("MM-DD-YYYY")
          .split("T")[0]
          .replace(/-/gi, "/")}`,
    asset_tag: Math.floor(Math.random() * 1000),
    product_key: Math.floor(Math.random() * 500),
    serial_no: Math.floor(Math.random() * 500),
  };
}

function range(len) {
  const arr = [];

  for (let i = 0; i < len; i++) {
    arr.push(i);
  }

  return arr;
}

export default function MakeDataListForm(hideLicenseColumns, ...lens) {
  const generateData = () => {
    // const len = lens[depth];

    return range(lens).map((one, i) => {
      return {
        ...makeRow(hideLicenseColumns),
      };
    });
  };

  return generateData();
}
