import React, { useState, useEffect } from "react";
import {
  useTable,
  useSortBy,
  useGlobalFilter,
  usePagination
  // useExpanded
} from "react-table";
// import { makeStyles } from "@material-ui/core/styles";

// import { makeStyles } from "@material-ui/core/styles";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
// import InputLabel from "@material-ui/core/InputLabel";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
// import useRouteMatch from "react-router-dom";
// import { Link } from "react-router-dom";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import TableContainer from "@material-ui/core/TableContainer";
import styled from "styled-components";
// import Input2 from "@material-ui/core/Input";
import ArrowUpwardIcon from "@material-ui/icons/ArrowUpward";
// import styled from "styled-components";

const TableStyles = styled(Table)`
  min-width: 650px;
  /* position: relative; */

  th {
    text-align: center;
    /* border-right: 1px solid #e4e4e4; */
    transition: 300ms background;
    /* display: flex; */
    /* justify-content: center;
    align-items: center; */

    /* &:hover {
      background: #f4f4f4;
    } */

    &.global-filter-th {
      padding: 0 8px;
      :hover {
        background: unset;
      }
    }
  }

  td {
    text-align: center;
  }

  tbody tr:nth-child(odd) {
    background: #fdfdfd;
  }
`;

export const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
    maxWidth: 300
  },
  chips: {
    display: "flex",
    flexWrap: "wrap"
  },
  chip: {
    margin: 2
  },
  noLabel: {
    marginTop: theme.spacing(3)
  },
  tablecell: {
    padding: "25px",
    fontSize: "14px",
    color: "rgba(0, 0, 0, 0.57)"
  }
}));
const TableHeadSpan = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;

  svg {
    font-size: 16px;
    margin-left: 3px;
  }

  /* &:hover {} */
`;

export default function MakeTable({
  columns,
  data,
  hideLicenseColumns

  // hiddenColumns = [],
}) {
  const instanceTable = useTable(
    {
      columns,
      data,
      initialState: {
        pageIndex: 0,
        pageSize: 10
      }
      // hiddenColumns: columns
      //   .filter((column) => column.show === false)
      //   .map((column) => column.Header),
    },

    useGlobalFilter,
    useSortBy,
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    page,
    prepareRow,
    allColumns
    // getToggleHideAllColumnsProps,
  } = instanceTable;

  useEffect(() => {
    hideLicenseColumns &&
      allColumns.map((column) => column.show && column.toggleHidden(true));
  }, [allColumns, hideLicenseColumns]);

  const [openNewRow, setOpenNewRow] = useState(false);
  // const [personName, setPersonName] = useState([]);
  //   const [tableNavDropdownValues, setTableNavDropdownValues] = useState([]);

  const classes = useStyles();

  return (
    <>
      <TableContainer
        component={Paper}
        style={{ overflowY: "hidden" }}
        // onScroll={handleScrollTable}
      >
        <TableStyles
          {...getTableProps}
          style={{
            borderCollapse: "unset"
          }}
          // stickyHeader
          // className={classes.table}
          aria-label="sticky table"
        >
          <TableHead>
            {headerGroups.map((headerGroup, i) => (
              <TableRow
                {...headerGroup.getHeaderGroupProps()}
                // className={classes.tablerow}
              >
                {headerGroup.headers.map((column, i) => (
                  // column.Header === personName[0]
                  //   ? (column.isVisible = false)
                  //   : "",
                  // console.log(column.Header === personName[0]),
                  // console.log(column.columns ? column.columns.concat() : ""),
                  <TableCell
                    {...column.getHeaderProps(column.getSortByToggleProps())}
                    className={classes.tablecell}
                    style={{
                      // backgroundColor: "#f4f4f4",
                      cursor: "pointer"
                    }}
                  >
                    <TableHeadSpan>
                      {column.render("Header")}

                      {column.isSorted ? (
                        column.isSortedDesc ? (
                          <ArrowUpwardIcon
                            fontSize="small"
                            color="disabled"
                          ></ArrowUpwardIcon>
                        ) : (
                          <ArrowUpwardIcon
                            fontSize="small"
                            style={{
                              transform: "rotate(180deg)",
                              transition: "250ms transform"
                            }}
                            color="disabled"
                          ></ArrowUpwardIcon>
                        )
                      ) : (
                        ""
                      )}
                    </TableHeadSpan>
                  </TableCell>
                ))}
              </TableRow>
            ))}

            <TableRow
              style={{
                display: openNewRow ? "table-row" : "none",
                transform: "scale(1)"
              }}
            ></TableRow>
          </TableHead>
          {/* <TableRow className="spacer"></TableRow> */}
          <TableBody {...getTableBodyProps}>
            {page.map((row, i) => {
              prepareRow(row);
              return (
                <TableRow {...row.getRowProps()} data-id={`${row.original.id}`}>
                  {row.cells.map((cell) => (
                    <TableCell {...cell.getCellProps()}>
                      {cell.render("Cell")}
                    </TableCell>
                  ))}
                </TableRow>
              );
            })}
          </TableBody>
        </TableStyles>
      </TableContainer>
    </>
  );
}
