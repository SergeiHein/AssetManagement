import React from "react";
import namor from "namor";
import { v4 as uuidv4 } from "uuid";
import momentRandom from "moment-random";
import moment from "moment";

// console.log(moment(momentRandom()._d).format());

// console.log(momentRandom()._d.format());

function makePerson() {
  const chance = Math.random();

  console.log(JSON.stringify(moment(new Date()).format().split("+")[0]));

  return {
    id: uuidv4(),
    firstName: namor.generate({ words: 1, saltLength: 0 }),
    lastName: namor.generate({ words: 1, saltLength: 0 }),
    Birthdate: `${moment(momentRandom()._d)
      .format("MM-DD-YYYY")
      .split("T")[0]
      .replace(/-/gi, "/")}`,
    visits: Math.floor(Math.random() * 10),
    progress: Math.floor(Math.random() * 100),
    status: chance > 0.5 ? "single" : "married"
  };
}

function range(len) {
  const arr = [];

  for (let i = 0; i < len; i++) {
    arr.push(i);
  }

  return arr;
}

export default function MakeData(...lens) {
  const generateData = (depth = 0) => {
    const len = lens[depth];

    return range(len).map((one, i) => {
      // console.log(i, i % 2 === 1);
      // console.log(lens[depth + 1]);
      return {
        ...makePerson(),
        subRows: i === 3 || i === 15 ? generateData(depth + 1) : undefined
        // subRows: lens[depth + 1] ? generateData(depth + 1) : undefined
      };
    });
  };

  return generateData();
}
