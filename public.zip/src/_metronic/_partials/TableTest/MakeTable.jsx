import React, { useState, useEffect } from "react";
import {
  useTable,
  useSortBy,
  useFilters,
  useGlobalFilter,
  useAsyncDebounce,
  usePagination,
  // useExpanded
} from "react-table";
// import { makeStyles } from "@material-ui/core/styles";
import { makeStyles, useTheme } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import InputLabel from "@material-ui/core/InputLabel";
import TableCell from "@material-ui/core/TableCell";
import TableHead from "@material-ui/core/TableHead";
// import useRouteMatch from "react-router-dom";
import { Link } from "react-router-dom";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import TableContainer from "@material-ui/core/TableContainer";
import styled from "styled-components";
import Input from "@material-ui/core/TextField";
import Input2 from "@material-ui/core/Input";
import ArrowUpwardIcon from "@material-ui/icons/ArrowUpward";
import GetAppIcon from "@material-ui/icons/GetApp";
import Button from "@material-ui/core/Button";

// import AddBoxIcon from "@material-ui/icons/AddBox";
import IconButton from "@material-ui/core/IconButton";
// import Button from "@material-ui/core/Button";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import NavigateBeforeIcon from "@material-ui/icons/NavigateBefore";
// import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
// import FormHelperText from "@material-ui/core/FormHelperText";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
// import Chip from "@material-ui/core/Chip";
import Checkbox from "@material-ui/core/Checkbox";
// import ListItemText from "@material-ui/core/ListItemText";
// import InputBase from "@material-ui/core/InputBase";

// import AddNewRow from "./AddNewRow";
// import styled from "styled-components";

const TableStyles = styled(Table)`
  min-width: 650px;
  /* position: relative; */

  th {
    text-align: center;
    /* border-right: 1px solid #e4e4e4; */
    transition: 300ms background;
    /* display: flex; */
    /* justify-content: center;
    align-items: center; */

    /* &:hover {
      background: #f4f4f4;
    } */

    &.global-filter-th {
      padding: 0 8px;
      :hover {
        background: unset;
      }
    }
  }

  td {
    text-align: center;
  }

  tbody tr:nth-child(odd) {
    background: #fdfdfd;
  }

  /* thead {
    position: fixed;
    top: 0;
    left: 0;
  } */
  /* display: none; */
`;

// const TableHeadStyles = styled(TableHead)`
//   position: sticky;
//   z-index: 1;
// `;
export const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
    maxWidth: 300,
  },
  chips: {
    display: "flex",
    flexWrap: "wrap",
  },
  chip: {
    margin: 2,
  },
  noLabel: {
    marginTop: theme.spacing(3),
  },
  // tablerow: {
  // },
  tablecell: {
    padding: "25px",
    fontSize: "14px",
    color: "rgba(0, 0, 0, 0.57)",
  },
}));
const TableHeadSpan = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;

  svg {
    font-size: 16px;
    margin-left: 3px;
  }

  /* &:hover {} */
`;

const AddAssetWrapper = styled.div`
  /* width: 100%; */

  display: flex;
  align-items: center;
  justify-content: center;
`;

const TableOptionsWrapper = styled.div`
  width: 100%;
  flex: 1;
  display: flex;
  justify-content: space-evenly;
  align-items: center;
`;
// const FakeScrollBar = styled.div`
//   height: 20px;
//   width: 1000px;
// `;

const TableNavWrapper = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

const TableNavRight = styled.div`
  display: flex;
  flex-direction: row;
  /* width: 40%; */

  justify-content: space-between;
  align-items: flex-end;
  max-width: 500px;
  width: 400px;
  /* flex-direction: row-reverse; */
  /* margin-bottom: 25px; */
`;

const PaginationStyles = styled.div`
  /* flex: 1; */
  width: 300px;
  margin: ${(props) => (props.top ? "0" : "25px 0 0 auto")};
  /* float: right; */
  /* margin: 0 0 25px auto; */
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const TableHeaderWrapper = styled.div`
  display: flex;
  flex-direction: row;
  /* margin-bottom: 25px; */
  justify-content: space-between;
  width: 100%;
  height: 135px;
  padding: 25px;
  margin: 25px auto;
  background: #fff;
  border-radius: 3px;
  box-shadow: 0 0 50px 0 rgba(82, 63, 105, 0.15);
  /* border-bottom: 1px solid #efefef; */
`;
function GlobalFilter({
  preGlobalFilteredRows,
  globalFilter,
  setGlobalFilter,
}) {
  const [value, setValue] = useState(globalFilter);
  const count = preGlobalFilteredRows.length;
  const onChange = useAsyncDebounce((value) => {
    setGlobalFilter(value || undefined);
  }, 200);

  return (
    <Input
      // placeholder="Placeholder"
      inputProps={{ "aria-label": "description" }}
      value={value || ""}
      style={{ marginRight: "15px" }}
      label="Search"
      onChange={(e) => {
        setValue(e.target.value);
        onChange(e.target.value);
      }}
      placeholder={`${count} records...`}
      InputLabelProps={{
        shrink: true,
      }}
      variant="outlined"
    />
  );
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};
export default function MakeTable({
  columns,
  data,
  // hiddenColumns = [],
}) {
  const instanceTable = useTable(
    {
      columns,
      data,
      initialState: {
        pageIndex: 0,
        pageSize: 10,
      },
      // hiddenColumns: columns
      //   .filter((column) => column.show === false)
      //   .map((column) => column.Header),
    },

    useFilters,
    useGlobalFilter,
    useSortBy,
    usePagination
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,

    page,
    state,

    prepareRow,
    preGlobalFilteredRows,
    setGlobalFilter,
    canPreviousPage,
    canNextPage,
    nextPage,
    previousPage,
    setPageSize,
    pageOptions,
    allColumns,

    state: { pageIndex, pageSize },
  } = instanceTable;

  useEffect(() => {
    allColumns.map((column) => column.hidden && column.toggleHidden(true));
  }, [allColumns]);

  // console.log(
  //   columns.filter((one) => one.show === false).map((one) => one.Header)
  // );

  const [openNewRow, setOpenNewRow] = useState(false);
  const [personName, setPersonName] = useState([]);
  const [formName, setFormName] = useState();
  // const [tableNavDropdownValues, setTableNavDropdownValues] = useState([]);
  const [age, setAge] = React.useState("");

  const classes = useStyles();
  // const theme = useTheme();

  // const match = useRouteMatch();

  // const tableScrollRef = useRef();
  // const fakeScrollRef = useRef();

  const handleAgeChange = (event) => {
    setAge(event.target.value);
  };

  // useEffect(() => {
  //   setTableNavDropdownValues(
  //     headerGroups[0].headers
  //       .filter((one) => one.accessor)
  //       .map((header) => header.Header)
  //   );
  // }, [headerGroups]);

  const handleChange = (event) => {
    setPersonName(event.target.value);
  };

  // console.log(personName);
  return (
    <>
      <TableHeaderWrapper>
        <TableNavWrapper>
          <GlobalFilter
            preGlobalFilteredRows={preGlobalFilteredRows}
            setGlobalFilter={setGlobalFilter}
            globalFilter={state.globalFilter}
          ></GlobalFilter>

          <TableNavRight>
            <AddAssetWrapper>
              <Link
                to={{
                  pathname: "list-table/list-new-form",
                  state: { formName },
                }}
                variant="contained"
                color="secondary"
                size="small"
                onClick={() => {
                  setFormName("new");
                  setOpenNewRow(!openNewRow);
                }}
                style={{ height: "35px" }}
              >
                <Button variant="contained" color="secondary">
                  Add New Asset
                </Button>
              </Link>
            </AddAssetWrapper>

            <TableOptionsWrapper>
              <FormControl style={{ width: "75px" }}>
                <InputLabel id="demo-simple-select-label">
                  <GetAppIcon></GetAppIcon>
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={age}
                  onChange={handleAgeChange}
                  label="Age"
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  <MenuItem value="Excel">Excel</MenuItem>
                  <MenuItem value="PDF">PDF</MenuItem>
                  <MenuItem value="JSON">JSON</MenuItem>
                </Select>
              </FormControl>
              <FormControl
                className={classes.formControl}
                style={{ maxWidth: "150px" }}
              >
                <InputLabel id="demo-mutiple-checkbox-label">Tag</InputLabel>
                <Select
                  labelId="demo-mutiple-checkbox-label"
                  id="demo-mutiple-checkbox"
                  multiple
                  value={personName}
                  onChange={handleChange}
                  input={<Input2 />}
                  renderValue={(selected) => selected.join(", ")}
                  MenuProps={MenuProps}
                >
                  {allColumns
                    .filter((column) => column.accessor)
                    .map((column) => (
                      // console.log(column),
                      <InputLabel style={{ cursor: "pointer" }}>
                        <Checkbox
                          checked={personName.indexOf(column.id) > -1}
                          {...column.getToggleHiddenProps()}
                        />
                        {column.Header}
                      </InputLabel>
                      // <MenuItem key={column.id} value={column.id}>

                      // </MenuItem>
                    ))}
                </Select>
              </FormControl>
            </TableOptionsWrapper>

            {/* <Route path="/list-table/list-new-form" component={ListNewForm} /> */}
          </TableNavRight>
        </TableNavWrapper>
      </TableHeaderWrapper>
      <TableContainer component={Paper} style={{ overflowY: "hidden" }}>
        <TableStyles
          {...getTableProps}
          style={{
            borderCollapse: "unset",
          }}
          // stickyHeader
          // className={classes.table}
          aria-label="sticky table"
        >
          <TableHead>
            {headerGroups.map((headerGroup, i) => (
              <TableRow
                {...headerGroup.getHeaderGroupProps()}
                // className={classes.tablerow}
              >
                {headerGroup.headers.map((column, i) => (
                  // column.Header === personName[0]
                  //   ? (column.isVisible = false)
                  //   : "",
                  // console.log(column.Header === personName[0]),
                  // console.log(column.columns ? column.columns.concat() : ""),
                  <TableCell
                    {...column.getHeaderProps(column.getSortByToggleProps())}
                    className={classes.tablecell}
                    style={{
                      // backgroundColor: "#f4f4f4",
                      cursor: "pointer",
                      minWidth: "125px",
                      maxWidth: "200px",
                    }}
                  >
                    <TableHeadSpan>
                      {column.render("Header")}

                      {column.isSorted ? (
                        column.isSortedDesc ? (
                          <ArrowUpwardIcon
                            fontSize="small"
                            color="disabled"
                          ></ArrowUpwardIcon>
                        ) : (
                          <ArrowUpwardIcon
                            fontSize="small"
                            style={{
                              transform: "rotate(180deg)",
                              transition: "250ms transform",
                            }}
                            color="disabled"
                          ></ArrowUpwardIcon>
                        )
                      ) : (
                        ""
                      )}
                    </TableHeadSpan>
                  </TableCell>
                ))}
              </TableRow>
            ))}

            <TableRow
              style={{ transform: "scale(1)" }}
              style={{ display: openNewRow ? "table-row" : "none" }}
            >
              {/* <AddNewRow
                oriData={oriData}
                setOriData={setOriData}
                setSelectedId={setSelectedId}
                setDialogOpen={setDialogOpen}
              ></AddNewRow> */}
            </TableRow>
          </TableHead>
          {/* <TableRow className="spacer"></TableRow> */}
          <TableBody {...getTableBodyProps}>
            {page.map((row, i) => {
              // console.log(row);
              // console.log(row);
              prepareRow(row);
              // console.log(row);
              return (
                <TableRow {...row.getRowProps()} data-id={`${row.original.id}`}>
                  {row.cells.map((cell) => (
                    <TableCell {...cell.getCellProps()}>
                      {cell.render("Cell")}
                    </TableCell>
                  ))}
                </TableRow>
              );
            })}
          </TableBody>
        </TableStyles>
      </TableContainer>
      <PaginationStyles bottom>
        {" "}
        {/* <IconButton></IconButton> */}
        <IconButton onClick={() => previousPage()} disabled={!canPreviousPage}>
          <NavigateBeforeIcon></NavigateBeforeIcon>
        </IconButton>{" "}
        <IconButton onClick={() => nextPage()} disabled={!canNextPage}>
          <NavigateNextIcon></NavigateNextIcon>
        </IconButton>{" "}
        <span>
          Page{" "}
          <strong>
            {pageIndex + 1} of {pageOptions.length}
          </strong>{" "}
        </span>
        <FormControl>
          {/* <InputLabel id="demo-simple-select-label">P</InputLabel> */}
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
          >
            {[10, 20].map((pageSize) => (
              <MenuItem id={pageSize} value={pageSize}>
                Show {pageSize}
              </MenuItem>
              // <option key={pageSize} value={pageSize}>
              //   Show {pageSize}
              // </option>
            ))}
          </Select>
        </FormControl>
      </PaginationStyles>
    </>
  );
}
