import React, { useMemo, useState, useEffect } from "react";
import MakeData from "./layout/MakeData";
import MakeTable from "./MakeTable";
import styled from "styled-components";
import CreateIcon from "@material-ui/icons/Create";
// import AddCircleIcon from "@material-ui/icons/AddCircle";
import DeleteIcon from "@material-ui/icons/Delete";
import EditTableData from "./EditTableData";
// import GlobalFilter from "./GlobalFilter";
// import TableCell from "@material-ui/core/TableCell";
// import TableHead from "@material-ui/core/TableHead";
// import TableRow from "@material-ui/core/TableRow";
import IconButton from "@material-ui/core/IconButton";
import AlertBox from "./layout/AlertBox";
import Tooltip from "@material-ui/core/Tooltip";
import { useSubheader } from "../../layout";
import { appsetting } from "../../../envirment/appsetting";

// import axios from "axios";

// import Axios from "axios";
// import CssBaseline from "@material-ui/core/CssBaseline";
// export const alertContext = createContext();

const Styles = styled.div`
  width: 100%;
  margin: 0px auto 0 auto;
  /* margin-top: 70px; */
`;

const DeleteButton = styled(IconButton)`
  padding: 7px !important;
  border-radius: 4px !important;
  background: rgba(244, 67, 54, 0.5) !important;
  transition: all 300ms;

  svg {
    color: #fff;
  }
  &:hover {
    background-color: rgba(244, 67, 54, 0.8) !important;
  }
`;

// const EditButton = styled(IconButton)`
//   &:hover {
//     background-color: rgba(54, 153, 255, 0.5) !important;
//     transition: 300ms;
//     svg {
//       color: #fff;
//     }
//   }
// `;

const EditButton = styled(IconButton)`
  padding: 7px !important;
  border-radius: 4px !important;
  background: rgba(54, 153, 255, 0.5) !important;
  transition: all 300ms;

  svg {
    color: #fff;
  }
  &:hover {
    background-color: rgba(54, 153, 255, 0.8) !important;
  }
`;

export default function App() {
  const suhbeader = useSubheader();
  suhbeader.setTitle("List Table");

  const [selectedId, setSelectedId] = useState();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [openAlert, setOpenAlert] = useState(false);
  // const server_path = "http://82.145.57.162:8087/";
  const [headers, setHeaders] = useState([]);
  const [columnHeaders, setColumnHeaders] = useState([]);
  const [columnValues, setColumnValues] = useState([]);
  const [oriData, setOriData] = useState([]);
  const selectedRow = oriData.find((row) => row.id === selectedId);
  const { server_path } = appsetting;

  // console.log(columnHeaders);

  // console.log(column)

  function handleEditChange(id, changes) {
    const newValues = [...oriData];

    const index = newValues.findIndex((value) => value.id === id);

    newValues[index] = changes;

    setOriData(newValues);
  }

  useEffect(() => {
    fetch(`${server_path}api/assetcolumnname`)
      .then((res) => res.json())
      .then((data) => {
        // console.log(data);
        setColumnHeaders(Object.keys(data));
      });
  }, []);

  useEffect(() => {
    fetch(`${server_path}api/assetdetail`)
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        setColumnValues(data);
      });
  }, []);

  // console.log(columnValues);

  useEffect(() => {
    setOriData(MakeData(columnValues));
  }, [columnValues]);

  useEffect(() => {
    columnHeaders.map((column) => {
      return setHeaders((prev) => {
        return [
          ...prev,
          {
            Header: column
              .replace("_", " ")
              .toLowerCase()
              .split(" ")
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(" "),
            accessor: column,
            hidden: column.toLowerCase() === "asset_id" ? true : undefined,
          },
        ];
      });
    });
  }, [columnHeaders]);

  // action buttons here

  // useEffect(() => {
  //   if (headers.length === columnHeaders.length) {
  //     return setHeaders((prev) => {
  //       return [
  //         ...prev,
  //         {
  //           Header: "Actions",
  //           id: "delete",
  //           Cell: (tableProps) => {
  //             return (
  //               <>
  //                 <span
  //                   style={{
  //                     cursor: "pointer",
  //                     color: "#353535",
  //                     textDecoration: "underline",
  //                     marginRight: "10px",
  //                   }}
  //                   onClick={() => {
  //                     // console.log(oriData);
  //                     const dataCopy = [...oriData];
  //                     dataCopy.splice(tableProps.row.index, 1);

  //                     // console.log(dataCopy);
  //                     setOriData(dataCopy);
  //                     setOpenAlert(true);
  //                     setTimeout(() => {
  //                       setOpenAlert(false);
  //                     }, 2500);
  //                     // console.log(oriData);
  //                   }}
  //                 >
  //                   <Tooltip title="Delete Row">
  //                     <DeleteButton aria-label="delete">
  //                       <DeleteIcon fontSize="small" />
  //                     </DeleteButton>
  //                   </Tooltip>
  //                 </span>
  //                 <span
  //                   style={{
  //                     cursor: "pointer",
  //                     color: "grey",
  //                     textDecoration: "underline",
  //                   }}
  //                   onClick={(event) => {
  //                     let id =
  //                       event.currentTarget.parentElement.parentElement.dataset
  //                         .id;
  //                     setDialogOpen(true);
  //                   }}
  //                 >
  //                   <Tooltip title="Edit Row">
  //                     <EditButton aria-label="edit">
  //                       <CreateIcon fontSize="small" />
  //                     </EditButton>
  //                   </Tooltip>
  //                 </span>
  //               </>
  //             );
  //           },
  //         },
  //       ];
  //     });
  //   }
  // }, [headers, oriData, columnHeaders.length]);

  // console.log(headers);

  // console.log([...new Set(headers.map((one) => one.id))]);

  // function generateColumnHeaders() {
  //   return columnHeaders.map((column) => {
  //     return [
  //       {
  //         Header: column,
  //         accessor: column,
  //       },
  //     ];
  //   });
  // }

  // const columns = React.useMemo(
  //   () => [
  //     {
  //       Header: "First Name",
  //       accessor: "firstName",

  //     },
  //     {
  //       Header: "Last Name",
  //       accessor: "lastName",
  //       // show: false,
  //     },
  //     {
  //       Header: "Birthdate",
  //       accessor: "Birthdate",
  //     },
  //     {
  //       Header: "Visits",
  //       accessor: "visits",
  //     },
  //     {
  //       Header: "Status",
  //       accessor: "status",
  //     },
  //     {
  //       Header: "Profile Progress",
  //       accessor: "progress",
  //     },
  //     {
  //       Header: "Actions",
  //       id: "delete",
  //       Cell: (tableProps) => {
  //         return (
  //           <>
  //             <span
  //               style={{
  //                 cursor: "pointer",
  //                 color: "#353535",
  //                 textDecoration: "underline",
  //                 marginRight: "10px",
  //               }}
  //               onClick={() => {
  //                 const dataCopy = [...oriData];
  //                 dataCopy.splice(tableProps.row.index, 1);
  //                 setOriData(dataCopy);
  //                 setOpenAlert(true);
  //                 setTimeout(() => {
  //                   setOpenAlert(false);
  //                 }, 2500);
  //               }}
  //             >
  //               <Tooltip title="Delete Row">
  //                 <DeleteButton aria-label="delete">
  //                   <DeleteIcon fontSize="small" />
  //                 </DeleteButton>
  //               </Tooltip>
  //             </span>
  //             <span
  //               style={{
  //                 cursor: "pointer",
  //                 color: "grey",
  //                 textDecoration: "underline",
  //               }}
  //               onClick={(event) => {
  //                 let id =
  //                   event.currentTarget.parentElement.parentElement.dataset.id;
  //                 setDialogOpen(true);
  //               }}
  //             >
  //               <Tooltip title="Edit Row">
  //                 <EditButton aria-label="edit">
  //                   <CreateIcon fontSize="small" />
  //                 </EditButton>
  //               </Tooltip>
  //             </span>
  //           </>
  //         );
  //       },
  //     },
  //   ],
  //   [oriData]
  // );

  const columns = useMemo(() => headers, [headers]);

  // console.log(headers);

  const data = useMemo(() => oriData, [oriData]);

  return (
    // <alertContext.Provider value={contextValues}>
    <Styles>
      <MakeTable
        columns={columns}
        data={data}
        oriData={oriData}
        setOriData={setOriData}
        setSelectedId={setSelectedId}
        setDialogOpen={setDialogOpen}
      ></MakeTable>
      {openAlert && (
        <AlertBox
          setOpenAlert={setOpenAlert}
          content="deleted row."
          refer="delete"
        ></AlertBox>
      )}
      {dialogOpen && (
        <EditTableData
          selectedRow={selectedRow}
          setDialogOpen={setDialogOpen}
          dialogOpen={dialogOpen}
          handleEditChange={handleEditChange}
        ></EditTableData>
      )}
    </Styles>
    // </alertContext.Provider>
  );
}
