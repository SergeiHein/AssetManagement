import React from "react";
import namor from "namor";
import { v4 as uuidv4 } from "uuid";
// import momentRandom from "moment-random";
// import moment from "moment";

// console.log(moment(momentRandom()._d).format());

// console.log(momentRandom()._d.format());

function makePerson(columnValue) {
  const objKeys = Object.keys(columnValue);

  // console.log(objKeys);

  return columnValue;
}

function range(len) {
  const arr = [];

  for (let i = 0; i < len; i++) {
    arr.push(i);
  }

  return arr;
}

export default function MakeData(columnValues) {
  const generateData = () => {
    console.log(columnValues);
    // const len = lens[depth];

    return columnValues.map((columnValue, i) => {
      return {
        ...makePerson(columnValue),
        // subRows: i === 3 || i === 15 ? generateData(depth + 1) : undefined,
      };
    });
  };

  return generateData();
}
